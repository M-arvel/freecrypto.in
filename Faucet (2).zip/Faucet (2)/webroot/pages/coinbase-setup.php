<?php

 require_once (dirname(dirname(__FILE__)).'/loader.php');

 $fun->do_winfo('COINBASE_SETUP');

 show('Pages/Help/coinbase-setup');

?>