<?php

 require_once (dirname(dirname(__FILE__)).'/loader.php');

 $fun->do_winfo('ADD_SHORTLINKS');

 show('Pages/Help/add-shortlinks');

?>