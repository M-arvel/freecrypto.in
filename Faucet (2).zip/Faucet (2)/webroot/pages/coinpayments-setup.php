<?php

 require_once (dirname(dirname(__FILE__)).'/loader.php');

 $fun->do_winfo('COINPAYMENTS_SETUP');
 
 show('Pages/Help/coinpayments-setup');

?>