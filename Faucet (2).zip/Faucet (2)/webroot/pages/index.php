<?php

 require_once (dirname(dirname(__FILE__)).'/loader.php');

 $fun->do_page_display();

 show('Pages/index');

?>