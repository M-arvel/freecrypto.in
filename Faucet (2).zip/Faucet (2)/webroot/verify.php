<?php

 require_once ('loader.php');

 $fun->do_verify_mail();

?>