<?php

 require_once "loader.php";

 $fun->do_notifications();
 $smart->sign_user_fun();
 secure_role();
 
?>