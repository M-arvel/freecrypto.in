<?php

 require_once ('functions.php');

 $fun->do_winfo('Redirect');

 $fun->do_redirect(6);
 
 show('User/Redirect/index');

?>