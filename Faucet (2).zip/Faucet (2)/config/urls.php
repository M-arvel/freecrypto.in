<?php

/**
 * URL to the Assets directory.
 */
define('AST', 'template' . DS . Theme . DS . 'Assets' . DS);

/**
 * URL to the Theme directory.
 */
define('THM', 'template' . DS . Theme . DS);

/**
 *
 * URL to the Admin directory.
 */
define('ADM', 'admin' . DS);

/**
 *
 * URL to the User directory.
 */
define('USR', 'user' . DS);